import html from "../skill/html2.png"
import css from "../skill/cssfinal.png"
import react from "../skill/react.png" 
import js from "../skill/js2.png" 
import mysql from "../skill/mysql.png" 
import node from "../skill/node.png" 


export default[
   {
      "title":"HTML",
       "imagenSrc":html
   },

   {
    "title":"CSS",
    "imagenSrc":css
   },

   {
    "title":"React",
    "imagenSrc":react
   },

   {
    "title":"Javasript",
    "imagenSrc":js
   },

   {
    "title":"Mysql",
    "imagenSrc":mysql 
   },

   {
    "title":"Node",
    "imagenSrc":node

   }
]