import app from "./app.js"
app.listen(4000)
console.log("servidor escuchando en el puerto",4000)

